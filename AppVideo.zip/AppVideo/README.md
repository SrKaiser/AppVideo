# AppVideo
 Repositorio dedicado al proyecto de prácticas de la asignatura de TDS que consiste en un reproductor de videos similar a Youtube.
